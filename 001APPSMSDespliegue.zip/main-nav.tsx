export const MainNav = ({ className }: { className?: string }) => {
    return (
      <div className={className}>
        <div>Main Nav</div>
      </div>
    )
  }
  
  